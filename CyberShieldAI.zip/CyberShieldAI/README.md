# CyberShield AI

Android VPN + on-device security monitor. Kotlin, Jetpack Compose, official WireGuard tunnel library (`com.wireguard.android:tunnel`) on top of `android.net.VpnService`.

## Build

1. Open this folder in Android Studio (Koala or newer, JDK 17). It creates the Gradle wrapper and downloads dependencies.
2. Run on a physical device (Android 8.0+). Emulators work for the UI but are poor for VPN testing.

## You need a real WireGuard server

The app does not simulate a VPN and ships no servers: you must supply real ones.

1. Install WireGuard on a VPS in each country you want (`apt install wireguard`), generate a key pair, and add a peer for the phone.
2. Create a client config per server and import it on the VPN tab. Optional `#` comments feed the UI and auto-selector:

```ini
# name: Frankfurt 1
# country: DE
# privacy: 8
# probe: 443
[Interface]
PrivateKey = <client private key>
Address = 10.8.0.2/32
DNS = 9.9.9.9

[Peer]
PublicKey = <server public key>
Endpoint = vpn.example.com:51820
AllowedIPs = 0.0.0.0/0, ::/0
PersistentKeepalive = 25
```

`DNS = 9.9.9.9` uses Quad9, which refuses known-malicious domains. That is real DNS-level filtering, but the resolver does not report counts to the app.

`probe` is a TCP port on the server used only to measure latency/loss (a refused connection still gives a valid round-trip time). Open or leave closed; either works, but a firewall that silently drops it will count as loss.

## What is real

- **VPN**: WireGuard (Curve25519, ChaCha20-Poly1305). "Encrypted" is shown only when a handshake completed within 3 minutes. Public IP/VPN IP come from api.ipify.org, only if the user consents.
- **Server choice**: measured latency, jitter and timeout rate from the device, plus the operator-declared privacy rating.
- **Monitoring** (foreground service, user-started): Wi-Fi security type (Android 13+), unexpected VPN drop, per-app upload spikes (needs Usage Access), and risky installed apps (permission combinations, non-store installs).
- **Alerts**: show why it was flagged, details only when Android provides them, and whether anything was blocked.

## Limits you should know

- Android 10+ does not let a normal app list other apps' connections (remote IP/port) or drop their packets. Alerts therefore say "not available" for those fields and **Blocked connections only counts traffic this app actually blocked, which is currently zero.** Real blocking would require this app to run its own packet-filtering VPN, which conflicts with using WireGuard through the system's single VPN slot.
- Heuristics can have false positives (a large cloud backup looks like an upload spike). Alerts are advice, not malware verdicts.
- The app never identifies attackers and never contacts or counterattacks any device. Nothing is sent to the developer.
- Use Android's Always-on VPN + "Block connections without VPN" for a real kill switch.

## Play Store notes

`QUERY_ALL_PACKAGES` and `PACKAGE_USAGE_STATS` need Play Console declarations; the VPN needs the VpnService declaration and a privacy policy.
