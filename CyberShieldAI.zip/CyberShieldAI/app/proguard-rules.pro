# Keep WireGuard tunnel classes (JNI)
-keep class com.wireguard.** { *; }
