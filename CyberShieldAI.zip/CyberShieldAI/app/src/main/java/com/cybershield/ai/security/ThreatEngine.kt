package com.cybershield.ai.security

import android.app.AppOpsManager
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Process
import com.cybershield.ai.Consent
import com.cybershield.ai.vpn.VpnManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class NetStatus { UNKNOWN, SAFE, CAUTION, RISK }

/**
 * Every check below uses real data from Android APIs. Nothing is simulated.
 * What Android does NOT let a normal app do (and therefore what we do not claim):
 *  - list other apps' individual connections (remote IP/port) on Android 10+
 *  - inspect or drop other apps' packets, unless the app itself is the VPN
 */
class ThreatEngine(
    private val ctx: Context,
    private val alerts: AlertStore,
    private val vpn: VpnManager,
    private val consent: Consent,
) {
    private val _running = MutableStateFlow(false)
    val running: StateFlow<Boolean> = _running
    private val _scanning = MutableStateFlow(false)
    /** true only while a real scan pass is executing */
    val scanning: StateFlow<Boolean> = _scanning
    private val _netStatus = MutableStateFlow(NetStatus.UNKNOWN)
    val netStatus: StateFlow<NetStatus> = _netStatus
    private val _netDetail = MutableStateFlow("Monitoring not started")
    val netDetail: StateFlow<String> = _netDetail
    private val _lastScan = MutableStateFlow(0L)
    val lastScan: StateFlow<Long> = _lastScan

    private var job: Job? = null
    private var lastAppScan = 0L
    private var wasUp = false
    private val baseline = HashMap<Int, Double>()   // uid -> EMA of tx bytes per window
    private val samples = HashMap<Int, Int>()
    private var lastWindowEnd = 0L

    fun start(scope: CoroutineScope) {
        if (job?.isActive == true || !consent.monitoring) return
        _running.value = true
        job = scope.launch {
            while (isActive) {
                _scanning.value = true
                try { scanOnce() } catch (_: Exception) { }
                _lastScan.value = System.currentTimeMillis()
                _scanning.value = false
                delay(30_000)
            }
        }
    }

    fun stop() { job?.cancel(); job = null; _running.value = false; _netDetail.value = "Monitoring stopped"; _netStatus.value = NetStatus.UNKNOWN }

    fun hasUsageAccess(): Boolean {
        val ops = ctx.getSystemService(AppOpsManager::class.java)
        val mode = ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun scanOnce() {
        checkNetwork()
        checkVpnDrop()
        if (hasUsageAccess()) checkTrafficAnomalies()
        val now = System.currentTimeMillis()
        if (now - lastAppScan > 10 * 60_000) { lastAppScan = now; checkApps() }
    }

    // ---- Network security status -------------------------------------------------------------
    private fun checkNetwork() {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        if (caps == null) { _netStatus.value = NetStatus.UNKNOWN; _netDetail.value = "No active network"; return }
        val onVpn = vpn.isUp.value
        val wifi = caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
            (onVpn && cm.allNetworks.any { cm.getNetworkCapabilities(it)?.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) == true })
        var open = false
        if (wifi) {
            try {
                @Suppress("DEPRECATION")
                val info = ctx.applicationContext.getSystemService(WifiManager::class.java).connectionInfo
                if (Build.VERSION.SDK_INT >= 33) {
                    open = info.currentSecurityType == WifiInfo.SECURITY_TYPE_OPEN
                }
            } catch (_: Exception) { }
        }
        when {
            open && !onVpn -> {
                _netStatus.value = NetStatus.RISK
                _netDetail.value = "Open Wi-Fi without VPN. Others on the network may read unencrypted traffic."
                alerts.post(Alert(System.nanoTime(), System.currentTimeMillis(), "Unsecured Wi-Fi network", Severity.HIGH,
                    "You're connected to a Wi-Fi network with no encryption (open) and the VPN is off. Traffic that isn't HTTPS can be read by other people on that network. Connect the VPN or switch networks.",
                    block = BlockStatus.NOT_APPLICABLE, dedupeKey = "open-wifi"))
            }
            open -> { _netStatus.value = NetStatus.CAUTION; _netDetail.value = "Open Wi-Fi, traffic protected by VPN tunnel" }
            onVpn -> { _netStatus.value = NetStatus.SAFE; _netDetail.value = "VPN tunnel active" }
            else -> { _netStatus.value = NetStatus.CAUTION; _netDetail.value = "No VPN. Traffic goes directly through your network." }
        }
    }

    private fun checkVpnDrop() {
        val up = vpn.isUp.value
        if (wasUp && !up && vpn.wantConnected) {
            alerts.post(Alert(System.nanoTime(), System.currentTimeMillis(), "VPN dropped unexpectedly", Severity.HIGH,
                "The tunnel went down although you did not disconnect. Your real IP address may be exposed. Reconnect, and enable 'Always-on VPN' + 'Block connections without VPN' in Android settings so traffic can't leak.",
                block = BlockStatus.NOT_BLOCKED, dedupeKey = "vpn-drop"))
        }
        wasUp = up
    }

    // ---- Per-app upload anomalies (needs Usage Access) ---------------------------------------
    private fun checkTrafficAnomalies() {
        val nsm = ctx.getSystemService(NetworkStatsManager::class.java)
        val end = System.currentTimeMillis()
        val start = if (lastWindowEnd == 0L) end - 5 * 60_000 else lastWindowEnd
        if (end - start < 60_000) return
        lastWindowEnd = end
        val perUid = HashMap<Int, Long>()
        for (type in intArrayOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
            try {
                val st = nsm.querySummary(type, null, start, end)
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) { st.getNextBucket(b); perUid.merge(b.uid, b.txBytes, Long::plus) }
                st.close()
            } catch (_: Exception) { }
        }
        val pm = ctx.packageManager
        val minutes = ((end - start) / 60_000.0).coerceAtLeast(1.0)
        for ((uid, tx) in perUid) {
            if (uid < Process.FIRST_APPLICATION_UID) continue
            val perMin = tx / minutes
            val ema = baseline[uid]
            val n = samples[uid] ?: 0
            if (ema != null && n >= 6 && tx > 10_000_000 && perMin > ema * 6) {
                val pkg = pm.getPackagesForUid(uid)?.firstOrNull()
                val label = pkg?.let { try { pm.getApplicationLabel(pm.getApplicationInfo(it, 0)).toString() } catch (_: Exception) { it } } ?: "uid $uid"
                alerts.post(Alert(System.nanoTime(), end, "Unusual upload: $label", Severity.WARNING,
                    "$label uploaded ${tx / 1_000_000} MB in the last ${minutes.toInt()} min, about ${(perMin / ema).toInt()}x its normal rate on this device. This can be a backup or video upload, but it can also mean data exfiltration. Android doesn't reveal the destination IP/port to other apps, so check the app and revoke permissions if unexpected.",
                    appPackage = pkg, block = BlockStatus.NOT_BLOCKED, dedupeKey = "traffic-$uid"))
            }
            baseline[uid] = if (ema == null) perMin else ema * 0.85 + perMin * 0.15
            samples[uid] = n + 1
        }
    }

    // ---- Installed app risk review (local only) ----------------------------------------------
    private fun checkApps() {
        val pm = ctx.packageManager
        val pkgs: List<PackageInfo> = if (Build.VERSION.SDK_INT >= 33)
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
        else @Suppress("DEPRECATION") pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)

        for (p in pkgs) {
            val ai = p.applicationInfo ?: continue
            if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0 || p.packageName == ctx.packageName) continue
            val perms = p.requestedPermissions?.toSet() ?: emptySet()
            val reasons = mutableListOf<String>()
            var score = 0
            fun add(cond: Boolean, pts: Int, why: String) { if (cond) { score += pts; reasons += why } }

            val installer = try {
                if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(p.packageName).installingPackageName
                else @Suppress("DEPRECATION") pm.getInstallerPackageName(p.packageName)
            } catch (_: Exception) { null }
            val trusted = installer in setOf("com.android.vending", "com.sec.android.app.samsungapps", "com.amazon.venezia", "com.huawei.appmarket")
            add(!trusted, 1, "not installed from a known app store")
            add("android.permission.BIND_ACCESSIBILITY_SERVICE" in perms, 3, "can read and control the screen (accessibility service)")
            add("android.permission.BIND_DEVICE_ADMIN" in perms, 3, "requests device-admin rights")
            add("android.permission.SYSTEM_ALERT_WINDOW" in perms, 2, "can draw over other apps (overlay attacks)")
            add("android.permission.REQUEST_INSTALL_PACKAGES" in perms, 2, "can install other apps")
            add("android.permission.READ_SMS" in perms || "android.permission.RECEIVE_SMS" in perms, 2, "can read SMS (one-time codes)")
            add("android.permission.BIND_NOTIFICATION_LISTENER_SERVICE" in perms, 2, "can read all notifications")
            add("android.permission.READ_CALL_LOG" in perms, 1, "can read call log")
            add("android.permission.RECORD_AUDIO" in perms && "android.permission.READ_CONTACTS" in perms && "android.permission.ACCESS_FINE_LOCATION" in perms, 1, "microphone + contacts + precise location")

            if (score >= 5 && !trusted) {
                val label = pm.getApplicationLabel(ai).toString()
                alerts.post(Alert(System.nanoTime(), System.currentTimeMillis(), "Risky app: $label", if (score >= 7) Severity.HIGH else Severity.WARNING,
                    "$label (${p.packageName}) was flagged because it is ${reasons.joinToString("; ")}. This is a permission/installation-source heuristic, not a malware verdict. Review it in Android settings and remove it if you don't recognise it.",
                    appPackage = p.packageName, block = BlockStatus.NOT_APPLICABLE, dedupeKey = "app-${p.packageName}"))
            }
        }
    }
}
