package com.cybershield.ai.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.net.ConnectException
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

data class ServerScore(
    val server: ServerProfile,
    val latencyMs: Int?,   // median RTT, null if unreachable
    val jitterMs: Int,
    val lossPct: Int,
    val score: Int,        // 0..100
)

/**
 * Ranks servers using measurements taken from this device:
 *  - latency: time to complete a TCP connect (a refused connect still returns a RST, so RTT is valid)
 *  - jitter: mean deviation between probes
 *  - loss/stability: share of probes that timed out
 * plus the operator-declared privacy rating from the config. Throughput is not probed here (it would
 * require sending data to the server); live speed is shown from the tunnel counters once connected.
 */
object ServerSelector {
    private const val PROBES = 5
    private const val TIMEOUT_MS = 1500

    suspend fun rank(servers: List<ServerProfile>): List<ServerScore> = coroutineScope {
        servers.map { async(Dispatchers.IO) { measure(it) } }.awaitAll().sortedByDescending { it.score }
    }

    suspend fun best(servers: List<ServerProfile>): ServerScore? =
        rank(servers).firstOrNull { it.latencyMs != null }

    private suspend fun measure(s: ServerProfile): ServerScore = withContext(Dispatchers.IO) {
        val rtts = mutableListOf<Int>()
        var lost = 0
        repeat(PROBES) {
            val t0 = System.nanoTime()
            try {
                Socket().use { it.connect(InetSocketAddress(s.host, s.probePort), TIMEOUT_MS) }
                rtts += ((System.nanoTime() - t0) / 1_000_000).toInt()
            } catch (e: ConnectException) {
                // Connection refused = host answered with RST, still a valid round trip.
                if (e.message?.contains("refused", true) == true) rtts += ((System.nanoTime() - t0) / 1_000_000).toInt() else lost++
            } catch (e: Exception) {
                lost++
            }
        }
        if (rtts.isEmpty()) return@withContext ServerScore(s, null, 0, 100, 0)
        val sorted = rtts.sorted()
        val median = sorted[sorted.size / 2]
        val jitter = if (rtts.size > 1) rtts.zipWithNext { a, b -> abs(a - b) }.average().toInt() else 0
        val loss = lost * 100 / PROBES
        val latencyPts = (40 - median / 8).coerceIn(0, 40)       // up to 40
        val jitterPts = (15 - jitter / 4).coerceIn(0, 15)         // up to 15
        val stabilityPts = (20 - loss / 3).coerceIn(0, 20)        // up to 20
        val privacyPts = s.privacy * 2.5                          // up to 25
        ServerScore(s, median, jitter, loss, (latencyPts + jitterPts + stabilityPts + privacyPts).toInt().coerceIn(0, 100))
    }
}
