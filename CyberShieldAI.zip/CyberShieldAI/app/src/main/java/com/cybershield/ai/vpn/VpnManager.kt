package com.cybershield.ai.vpn

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class VpnStats(
    val rxBytes: Long = 0,
    val txBytes: Long = 0,
    val rxBps: Long = 0,
    val txBps: Long = 0,
    /** true only if a WireGuard handshake completed recently, i.e. traffic is really being encrypted to the peer. */
    val handshakeFresh: Boolean = false,
)

/** Thin wrapper over the official WireGuard userspace backend (android.net.VpnService under the hood). */
class VpnManager(private val ctx: Context, private val scope: CoroutineScope) {
    private val backend = GoBackend(ctx)

    private val tunnel = object : Tunnel {
        override fun getName() = "cybershield"
        override fun onStateChange(newState: Tunnel.State) {
            _up.value = newState == Tunnel.State.UP
        }
    }

    private val _up = MutableStateFlow(false)
    val isUp: StateFlow<Boolean> = _up

    private val _active = MutableStateFlow<ServerProfile?>(null)
    val active: StateFlow<ServerProfile?> = _active

    private val _stats = MutableStateFlow(VpnStats())
    val stats: StateFlow<VpnStats> = _stats

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    /** Set when the user asked to be connected; used to detect unexpected drops. */
    @Volatile var wantConnected = false
        private set

    init {
        scope.launch {
            var lastRx = 0L; var lastTx = 0L
            while (isActive) {
                if (_up.value) {
                    try {
                        val s = backend.getStatistics(tunnel)
                        val rx = s.totalRx(); val tx = s.totalTx()
                        val now = System.currentTimeMillis()
                        val fresh = s.peers().any {
                            val h = s.peer(it)?.latestHandshakeEpochMillis() ?: 0L
                            h > 0 && now - h < 180_000
                        }
                        _stats.value = VpnStats(rx, tx, (rx - lastRx).coerceAtLeast(0), (tx - lastTx).coerceAtLeast(0), fresh)
                        lastRx = rx; lastTx = tx
                    } catch (_: Exception) { }
                } else {
                    lastRx = 0; lastTx = 0
                    _stats.value = VpnStats()
                }
                delay(1000)
            }
        }
    }

    /** The caller must have obtained VpnService permission first (VpnService.prepare). */
    suspend fun connect(server: ServerProfile) = withContext(Dispatchers.IO) {
        _error.value = null
        try {
            val cfg = Config.parse(server.conf.byteInputStream())
            wantConnected = true
            backend.setState(tunnel, Tunnel.State.UP, cfg)
            _active.value = server
        } catch (e: Exception) {
            wantConnected = false
            _error.value = e.message ?: e.javaClass.simpleName
        }
    }

    suspend fun disconnect() = withContext(Dispatchers.IO) {
        wantConnected = false
        try { backend.setState(tunnel, Tunnel.State.DOWN, null) } catch (e: Exception) { _error.value = e.message }
        _active.value = null
    }
}
