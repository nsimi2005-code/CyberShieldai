package com.cybershield.ai.net

import android.net.TrafficStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class Sample(val rxBps: Long, val txBps: Long)

/** Samples device-wide byte counters once a second (rolling 60 s). Includes traffic of all apps. */
class TrafficMonitor(scope: CoroutineScope) {
    private val _samples = MutableStateFlow<List<Sample>>(emptyList())
    val samples: StateFlow<List<Sample>> = _samples

    init {
        scope.launch {
            var lastRx = TrafficStats.getTotalRxBytes()
            var lastTx = TrafficStats.getTotalTxBytes()
            while (isActive) {
                delay(1000)
                val rx = TrafficStats.getTotalRxBytes()
                val tx = TrafficStats.getTotalTxBytes()
                if (rx >= 0 && tx >= 0 && lastRx >= 0 && lastTx >= 0) {
                    _samples.value = (_samples.value + Sample((rx - lastRx).coerceAtLeast(0), (tx - lastTx).coerceAtLeast(0))).takeLast(60)
                }
                lastRx = rx; lastTx = tx
            }
        }
    }
}
