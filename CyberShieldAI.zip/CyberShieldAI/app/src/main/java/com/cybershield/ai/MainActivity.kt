package com.cybershield.ai

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybershield.ai.ui.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CyberTheme { Root() } }
    }
}

@Composable
private fun Root() {
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var realIp by remember { mutableStateOf<String?>(null) }
    var vpnIp by remember { mutableStateOf<String?>(null) }
    var showConsent by remember { mutableStateOf(!Core.consent.answered) }
    val up by Core.vpn.isUp.collectAsState()

    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val requestNotif = { if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS) }

    fun refreshIp() {
        scope.launch {
            val ip = Core.ip.publicIp()
            if (Core.vpn.isUp.value) vpnIp = ip else { realIp = ip; vpnIp = null }
        }
    }
    LaunchedEffect(Unit) { refreshIp() }
    LaunchedEffect(up) { if (up) { kotlinx.coroutines.delay(2500); refreshIp() } }

    if (showConsent) {
        AlertDialog(
            onDismissRequest = {},
            containerColor = Cy.Card,
            title = { Text("Before you start", color = Cy.Green, fontFamily = Cy.Mono) },
            text = {
                Text(
                    "CyberShield AI works on your device and sends nothing to us.\n\n" +
                        "• Show my public IP: one HTTPS request to api.ipify.org when you allow it.\n" +
                        "• Monitoring: reads network type, per-app data totals (if you grant Usage Access) and installed-app permissions, locally only.\n" +
                        "• VPN: Android will ask you to approve a VPN connection. Traffic goes only to the server you import.\n\nYou can change both choices on the Shield tab.",
                    color = androidx.compose.ui.graphics.Color.White, fontSize = 13.sp,
                )
            },
            confirmButton = {
                TextButton({ Core.consent.ipLookup = true; Core.consent.answered = true; showConsent = false; refreshIp() }) { Text("Allow IP lookup", color = Cy.Green) }
            },
            dismissButton = { TextButton({ Core.consent.ipLookup = false; Core.consent.answered = true; showConsent = false }) { Text("No thanks", color = Cy.Dim) } },
        )
    }

    Column(Modifier.fillMaxSize().background(Cy.Bg).statusBarsPadding()) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> DashboardScreen(realIp, vpnIp)
                1 -> VpnScreen(realIp, vpnIp, ::refreshIp)
                else -> ShieldScreen { requestNotif() }
            }
        }
        Row(Modifier.fillMaxWidth().background(Cy.Card).navigationBarsPadding().padding(vertical = 10.dp), horizontalArrangement = Arrangement.SpaceAround) {
            listOf("DASH", "VPN", "SHIELD").forEachIndexed { i, t ->
                Text(t, color = if (tab == i) Cy.Green else Cy.Dim, fontWeight = FontWeight.Bold, fontFamily = Cy.Mono, letterSpacing = 2.sp,
                    modifier = Modifier.clickable { tab = i }.padding(horizontal = 18.dp, vertical = 6.dp))
            }
        }
    }
}
