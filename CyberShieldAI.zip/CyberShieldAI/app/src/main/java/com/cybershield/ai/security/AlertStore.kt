package com.cybershield.ai.security

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

enum class Severity { INFO, WARNING, HIGH }

/** Whether the app itself stopped the traffic. Honest by construction: only BLOCKED if we really blocked it. */
enum class BlockStatus(val label: String) {
    NOT_BLOCKED("Not blocked: Android doesn't let an app block this without being the VPN"),
    NOT_APPLICABLE("Not a connection: advisory only"),
    BLOCKED("Blocked"),
}

data class Alert(
    val id: Long,
    val time: Long,
    val title: String,
    val severity: Severity,
    /** Plain-language reason it was flagged. */
    val why: String,
    val appPackage: String? = null,
    /** Null when Android does not expose it to a normal app (usually the case on Android 10+). */
    val remoteIp: String? = null,
    val port: Int? = null,
    val protocol: String? = null,
    val block: BlockStatus = BlockStatus.NOT_APPLICABLE,
    val dedupeKey: String = title,
)

class AlertStore(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("alerts", Context.MODE_PRIVATE)
    private val _list = MutableStateFlow(load())
    val list: StateFlow<List<Alert>> = _list

    val blockedCount: Int get() = _list.value.count { it.block == BlockStatus.BLOCKED }

    fun post(a: Alert) {
        // Don't repeat the same alert within 6 hours.
        if (_list.value.any { it.dedupeKey == a.dedupeKey && a.time - it.time < 6 * 3600_000 }) return
        val l = (listOf(a) + _list.value).take(100)
        _list.value = l
        save(l)
        notify(a)
    }

    fun clear() { _list.value = emptyList(); save(emptyList()) }

    private fun notify(a: Alert) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Security alerts", NotificationManager.IMPORTANCE_HIGH))
        nm.notify(a.id.toInt(), NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(a.title)
            .setContentText(a.why)
            .setStyle(NotificationCompat.BigTextStyle().bigText(a.why))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build())
    }

    private fun load(): List<Alert> = try {
        val arr = JSONArray(prefs.getString("list", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            Alert(
                o.getLong("id"), o.getLong("time"), o.getString("title"), Severity.valueOf(o.getString("sev")),
                o.getString("why"), o.optString("pkg").ifEmpty { null }, o.optString("ip").ifEmpty { null },
                if (o.has("port")) o.getInt("port") else null, o.optString("proto").ifEmpty { null },
                BlockStatus.valueOf(o.getString("block")), o.getString("key"),
            )
        }
    } catch (_: Exception) { emptyList() }

    private fun save(l: List<Alert>) {
        val arr = JSONArray()
        l.forEach {
            val o = JSONObject().put("id", it.id).put("time", it.time).put("title", it.title)
                .put("sev", it.severity.name).put("why", it.why).put("block", it.block.name).put("key", it.dedupeKey)
            it.appPackage?.let { v -> o.put("pkg", v) }
            it.remoteIp?.let { v -> o.put("ip", v) }
            it.port?.let { v -> o.put("port", v) }
            it.protocol?.let { v -> o.put("proto", v) }
            arr.put(o)
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    companion object { const val CH = "alerts" }
}
