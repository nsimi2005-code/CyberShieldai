package com.cybershield.ai.vpn

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.wireguard.config.Config
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/**
 * A real WireGuard server profile imported by the user (or shipped by the operator).
 * Optional metadata comments in the .conf drive the UI and the auto-selector:
 *   # name: Frankfurt 1
 *   # country: DE
 *   # privacy: 8        (1-10, operator-declared: no-logs audit, jurisdiction, etc.)
 *   # probe: 443        (TCP port used only to measure latency/loss)
 */
data class ServerProfile(
    val id: String,
    val name: String,
    val country: String,
    val host: String,
    val privacy: Int,
    val probePort: Int,
    val conf: String,
)

object ConfParser {
    private fun meta(text: String, key: String) =
        Regex("^#\\s*$key\\s*:\\s*(.+)$", setOf(RegexOption.MULTILINE, RegexOption.IGNORE_CASE))
            .find(text)?.groupValues?.get(1)?.trim()

    /** Throws if the file is not a valid WireGuard config. */
    fun parse(text: String, fallbackName: String): ServerProfile {
        Config.parse(text.byteInputStream()) // validates keys, addresses, endpoint
        val endpoint = Regex("^\\s*Endpoint\\s*=\\s*(.+)$", setOf(RegexOption.MULTILINE, RegexOption.IGNORE_CASE))
            .find(text)?.groupValues?.get(1)?.trim()
            ?: throw IllegalArgumentException("Config has no Endpoint")
        val host = endpoint.substringBeforeLast(":").trim('[', ']')
        val name = meta(text, "name") ?: fallbackName
        return ServerProfile(
            id = (name + host).hashCode().toString(16),
            name = name,
            country = (meta(text, "country") ?: "??").uppercase(),
            host = host,
            privacy = (meta(text, "privacy")?.toIntOrNull() ?: 5).coerceIn(1, 10),
            probePort = meta(text, "probe")?.toIntOrNull() ?: 443,
            conf = text,
        )
    }
}

/** Server configs contain private keys, so they live in EncryptedSharedPreferences. */
class ServerStore(ctx: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        ctx, "servers",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )
    private val _list = MutableStateFlow(load())
    val list: StateFlow<List<ServerProfile>> = _list

    private fun load(): List<ServerProfile> {
        val arr = JSONArray(prefs.getString("list", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            ServerProfile(
                o.getString("id"), o.getString("name"), o.getString("country"), o.getString("host"),
                o.getInt("privacy"), o.getInt("probePort"), o.getString("conf"),
            )
        }
    }

    private fun save(l: List<ServerProfile>) {
        val arr = JSONArray()
        l.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("country", it.country)
                .put("host", it.host).put("privacy", it.privacy).put("probePort", it.probePort)
                .put("conf", it.conf))
        }
        prefs.edit().putString("list", arr.toString()).apply()
        _list.value = l
    }

    fun add(p: ServerProfile) = save(_list.value.filter { it.id != p.id } + p)
    fun remove(id: String) = save(_list.value.filter { it.id != id })
}
