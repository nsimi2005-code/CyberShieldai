package com.cybershield.ai.ui

import android.content.Context
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybershield.ai.Core
import com.cybershield.ai.vpn.ConfParser
import com.cybershield.ai.vpn.ServerProfile
import com.cybershield.ai.vpn.ServerScore
import com.cybershield.ai.vpn.ServerSelector
import kotlinx.coroutines.launch

@Composable
fun BigButton(text: String, color: Color, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().height(52.dp)
            .background(if (enabled) color.copy(alpha = .16f) else Cy.Card, RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { Text(text.uppercase(), color = if (enabled) color else Cy.Dim, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, fontFamily = Cy.Mono, fontSize = 13.sp) }
}

@Composable
fun VpnScreen(realIp: String?, vpnIp: String?, onRefreshIp: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val servers by Core.servers.list.collectAsState()
    val up by Core.vpn.isUp.collectAsState()
    val active by Core.vpn.active.collectAsState()
    val stats by Core.vpn.stats.collectAsState()
    val err by Core.vpn.error.collectAsState()
    var scores by remember { mutableStateOf<List<ServerScore>>(emptyList()) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<ServerProfile?>(null) }

    fun doConnect(p: ServerProfile) = scope.launch { busy = true; Core.vpn.connect(p); busy = false; onRefreshIp() }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        pending?.let { p -> if (VpnService.prepare(ctx) == null) doConnect(p) else msg = "VPN permission was not granted." }
        pending = null
    }
    fun connectWithPermission(p: ServerProfile) {
        val i = VpnService.prepare(ctx)
        if (i == null) doConnect(p) else { pending = p; permLauncher.launch(i) }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            val text = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            val name = uri.lastPathSegment?.substringAfterLast('/')?.removeSuffix(".conf") ?: "Server"
            Core.servers.add(ConfParser.parse(text, name)); msg = "Server imported."
        } catch (e: Exception) { msg = "Invalid WireGuard config: ${e.message}" }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        item { Text("VPN", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, fontFamily = Cy.Mono) }
        item {
            NeonCard(accent = if (up) Cy.Green else Cy.Dim) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Label("Your IP (no VPN)"); Text(realIp ?: "—", color = Color.White, fontFamily = Cy.Mono) }
                    Column(horizontalAlignment = Alignment.End) { Label("VPN IP"); Text(if (up) vpnIp ?: "—" else "—", color = Cy.Green, fontFamily = Cy.Mono) }
                }
                Spacer(Modifier.height(10.dp))
                Label("Status")
                Text(
                    if (up) (if (stats.handshakeFresh) "ENCRYPTED · WireGuard tunnel to ${active?.name}" else "TUNNEL UP · waiting for handshake")
                    else "NOT PROTECTED", color = if (up && stats.handshakeFresh) Cy.Green else if (up) Cy.Amber else Cy.Red, fontFamily = Cy.Mono, fontWeight = FontWeight.Bold,
                )
                if (up) {
                    Spacer(Modifier.height(8.dp))
                    Text("↓ ${fmtRate(stats.rxBps)}   ↑ ${fmtRate(stats.txBps)}", color = Cy.Blue, fontFamily = Cy.Mono)
                    Text("Total ↓ ${fmtBytes(stats.rxBytes)}  ↑ ${fmtBytes(stats.txBytes)}", color = Cy.Dim, fontSize = 11.sp, fontFamily = Cy.Mono)
                }
            }
        }
        item {
            if (up) BigButton(if (busy) "Disconnecting…" else "Disconnect", Cy.Red, !busy) { scope.launch { busy = true; Core.vpn.disconnect(); busy = false; onRefreshIp() } }
            else Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                BigButton(if (busy) "Measuring / connecting…" else "Connect · auto-select best", Cy.Green, servers.isNotEmpty() && !busy) {
                    scope.launch {
                        busy = true
                        scores = ServerSelector.rank(servers)
                        val best = scores.firstOrNull { it.latencyMs != null }
                        busy = false
                        if (best == null) msg = "No server answered the latency probe." else { selectedId = best.server.id; connectWithPermission(best.server) }
                    }
                }
                BigButton("Connect to selected server", Cy.Blue, servers.isNotEmpty() && !busy && selectedId != null) {
                    servers.firstOrNull { it.id == selectedId }?.let { connectWithPermission(it) }
                }
            }
        }
        (err ?: msg)?.let { item { Text(it, color = Cy.Amber, fontSize = 12.sp, fontFamily = Cy.Mono) } }

        item { Label("Servers (${servers.size})") }
        if (servers.isEmpty()) item {
            NeonCard { Text("No servers yet. CyberShield connects to a real WireGuard server that you or your provider operate. Import a .conf file below. See the README for the format.", color = Cy.Dim, fontSize = 13.sp) }
        }
        items(servers, key = { it.id }) { s ->
            val sc = scores.firstOrNull { it.server.id == s.id }
            NeonCard(Modifier.clickable { selectedId = s.id }, accent = if (selectedId == s.id) Cy.Green else Cy.Blue) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("${s.country}  ${s.name}", color = Color.White, fontWeight = FontWeight.Bold, fontFamily = Cy.Mono)
                        Text(
                            if (sc == null) "privacy ${s.privacy}/10 · not measured yet"
                            else if (sc.latencyMs == null) "unreachable"
                            else "${sc.latencyMs} ms · jitter ${sc.jitterMs} ms · loss ${sc.lossPct}% · privacy ${s.privacy}/10",
                            color = Cy.Dim, fontSize = 11.sp, fontFamily = Cy.Mono,
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        if (sc != null) Text("${sc.score}", color = Cy.Green, fontSize = 22.sp, fontWeight = FontWeight.Black, fontFamily = Cy.Mono)
                        Text("remove", color = Cy.Red, fontSize = 11.sp, modifier = Modifier.clickable { Core.servers.remove(s.id) })
                    }
                }
            }
        }
        item { BigButton("Import WireGuard .conf", Cy.Blue) { importer.launch(arrayOf("*/*")) } }
        item {
            BigButton("Measure all servers", Cy.Blue, servers.isNotEmpty() && !busy) { scope.launch { busy = true; scores = ServerSelector.rank(servers); busy = false } }
        }
        item { Text("Score = latency 40 + stability 20 + privacy rating 25 + jitter 15. Measured from this device. The privacy rating comes from the server's operator (config comment), not from this app.", color = Cy.Dim, fontSize = 11.sp) }
    }
}
