package com.cybershield.ai

import android.app.Application
import android.content.Context
import com.cybershield.ai.net.IpChecker
import com.cybershield.ai.net.TrafficMonitor
import com.cybershield.ai.security.AlertStore
import com.cybershield.ai.security.ThreatEngine
import com.cybershield.ai.vpn.ServerStore
import com.cybershield.ai.vpn.VpnManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/** Simple process-wide holder. No analytics, no remote logging: everything stays on the device. */
object Core {
    lateinit var app: Application
        private set
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    lateinit var consent: Consent
    lateinit var servers: ServerStore
    lateinit var vpn: VpnManager
    lateinit var alerts: AlertStore
    lateinit var traffic: TrafficMonitor
    lateinit var ip: IpChecker
    lateinit var threat: ThreatEngine

    fun init(application: Application) {
        if (this::app.isInitialized) return
        app = application
        consent = Consent(application)
        servers = ServerStore(application)
        alerts = AlertStore(application)
        vpn = VpnManager(application, scope)
        traffic = TrafficMonitor(scope)
        ip = IpChecker(consent)
        threat = ThreatEngine(application, alerts, vpn, consent)
    }
}

class CyberApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Core.init(this)
    }
}

/** User consent flags. Nothing is sent anywhere unless the matching flag is true. */
class Consent(ctx: Context) {
    private val p = ctx.getSharedPreferences("consent", Context.MODE_PRIVATE)
    var ipLookup: Boolean
        get() = p.getBoolean("ip_lookup", false)
        set(v) = p.edit().putBoolean("ip_lookup", v).apply()
    var monitoring: Boolean
        get() = p.getBoolean("monitoring", false)
        set(v) = p.edit().putBoolean("monitoring", v).apply()
    var answered: Boolean
        get() = p.getBoolean("answered", false)
        set(v) = p.edit().putBoolean("answered", v).apply()
}
