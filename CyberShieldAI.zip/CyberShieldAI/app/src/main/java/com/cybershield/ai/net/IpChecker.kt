package com.cybershield.ai.net

import com.cybershield.ai.Consent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Looks up the public IP using api.ipify.org. This sends an HTTPS request from the device
 * (the service sees the IP, as any website would) and is only done when the user consented.
 */
class IpChecker(private val consent: Consent) {
    suspend fun publicIp(): String? {
        if (!consent.ipLookup) return null
        return withContext(Dispatchers.IO) {
            try {
                val c = URL("https://api.ipify.org?format=json").openConnection() as HttpURLConnection
                c.connectTimeout = 5000; c.readTimeout = 5000
                c.inputStream.bufferedReader().use { JSONObject(it.readText()).getString("ip") }
            } catch (_: Exception) { null }
        }
    }
}
