package com.cybershield.ai.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybershield.ai.Core
import com.cybershield.ai.security.Alert
import com.cybershield.ai.security.MonitorService
import com.cybershield.ai.security.NetStatus
import com.cybershield.ai.security.Severity
import java.text.DateFormat
import java.util.Date

@Composable
fun DashboardScreen(realIp: String?, vpnIp: String?) {
    val up by Core.vpn.isUp.collectAsState()
    val active by Core.vpn.active.collectAsState()
    val stats by Core.vpn.stats.collectAsState()
    val running by Core.threat.running.collectAsState()
    val scanning by Core.threat.scanning.collectAsState()
    val net by Core.threat.netStatus.collectAsState()
    val detail by Core.threat.netDetail.collectAsState()
    val alerts by Core.alerts.list.collectAsState()
    val samples by Core.traffic.samples.collectAsState()

    val netColor = when (net) { NetStatus.SAFE -> Cy.Green; NetStatus.CAUTION -> Cy.Amber; NetStatus.RISK -> Cy.Red; NetStatus.UNKNOWN -> Cy.Dim }
    val netText = when (net) { NetStatus.SAFE -> "SECURE"; NetStatus.CAUTION -> "CAUTION"; NetStatus.RISK -> "AT RISK"; NetStatus.UNKNOWN -> "IDLE" }
    val recent = alerts.filter { System.currentTimeMillis() - it.time < 24 * 3600_000 }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        item { Text("CYBERSHIELD AI", color = Cy.Green, fontSize = 22.sp, fontWeight = FontWeight.Black, fontFamily = Cy.Mono, letterSpacing = 3.sp) }
        item {
            ScannerView(
                active = running, scanning = scanning, color = netColor,
                centerTop = netText,
                centerBottom = if (!running) "monitor off" else if (scanning) "scanning…" else "monitoring",
                modifier = Modifier.fillMaxWidth(0.72f),
            )
        }
        item { Text(detail, color = Cy.Dim, fontSize = 12.sp, fontFamily = Cy.Mono) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("Public IP", (if (up) vpnIp else realIp) ?: "—", Color.White, Modifier.weight(1f))
                Stat("VPN", if (up) (if (stats.handshakeFresh) "ON · encrypted" else "ON · handshake…") else "OFF", if (up) Cy.Green else Cy.Red, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("Country", active?.country ?: "—", Cy.Blue, Modifier.weight(1f))
                Stat("Blocked", "${Core.alerts.blockedCount}", Cy.Green, Modifier.weight(1f))
                Stat("Alerts 24h", "${recent.size}", if (recent.any { it.severity == Severity.HIGH }) Cy.Red else if (recent.isNotEmpty()) Cy.Amber else Cy.Green, Modifier.weight(1f))
            }
        }
        item {
            NeonCard {
                Label("Device traffic · last 60 s")
                Spacer(Modifier.height(8.dp))
                TrafficGraph(samples)
                val last = samples.lastOrNull()
                Text("↓ ${fmtRate(last?.rxBps ?: 0)}   ↑ ${fmtRate(last?.txBps ?: 0)}", color = Cy.Blue, fontFamily = Cy.Mono, fontSize = 12.sp)
                Text("all apps, as counted by Android", color = Cy.Dim, fontSize = 10.sp)
            }
        }
        item { Label("Latest alerts") }
        if (alerts.isEmpty()) item { Text("No alerts. Alerts only appear when a real check finds something.", color = Cy.Dim, fontSize = 12.sp) }
        items(alerts.take(3), key = { it.id }) { AlertCard(it) }
    }
}

@Composable
fun AlertCard(a: Alert) {
    var open by remember { mutableStateOf(false) }
    val col = when (a.severity) { Severity.HIGH -> Cy.Red; Severity.WARNING -> Cy.Amber; Severity.INFO -> Cy.Blue }
    val ctx = LocalContext.current
    NeonCard(Modifier.clickable { open = !open }, accent = col) {
        Text(a.title, color = col, fontWeight = FontWeight.Bold, fontFamily = Cy.Mono)
        Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(a.time)), color = Cy.Dim, fontSize = 10.sp, fontFamily = Cy.Mono)
        if (open) {
            Spacer(Modifier.height(8.dp))
            Label("Why it was flagged"); Text(a.why, color = Color.White, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Label("Technical details")
            Text(
                "Remote IP: ${a.remoteIp ?: "not available to apps on this Android version"}\n" +
                    "Port: ${a.port ?: "not available"}\nProtocol: ${a.protocol ?: "not available"}\n" +
                    "App: ${a.appPackage ?: "n/a"}",
                color = Cy.Dim, fontSize = 12.sp, fontFamily = Cy.Mono,
            )
            Spacer(Modifier.height(8.dp))
            Label("Blocked?"); Text(a.block.label, color = if (a.block.name == "BLOCKED") Cy.Green else Cy.Amber, fontSize = 12.sp)
            a.appPackage?.let { pkg ->
                Spacer(Modifier.height(8.dp))
                Text("Open app settings →", color = Cy.Blue, fontFamily = Cy.Mono, fontSize = 12.sp, modifier = Modifier.clickable {
                    ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                })
            }
        }
    }
}

@Composable
fun ShieldScreen(onRequestNotif: () -> Unit) {
    val ctx = LocalContext.current
    val alerts by Core.alerts.list.collectAsState()
    val running by Core.threat.running.collectAsState()
    var hasUsage by remember { mutableStateOf(Core.threat.hasUsageAccess()) }
    var consentMon by remember { mutableStateOf(Core.consent.monitoring) }
    var consentIp by remember { mutableStateOf(Core.consent.ipLookup) }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 16.dp)) {
        item { Text("ANTI-HACKER SHIELD", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black, fontFamily = Cy.Mono) }
        item {
            NeonCard(accent = Cy.Green) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("Real-time monitoring", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Runs as a visible foreground service. Everything is analysed on this device.", color = Cy.Dim, fontSize = 12.sp)
                    }
                    Switch(checked = running, onCheckedChange = { on ->
                        if (on) { Core.consent.monitoring = true; consentMon = true; Core.consent.answered = true; onRequestNotif(); MonitorService.start(ctx) }
                        else MonitorService.stop(ctx)
                    })
                }
            }
        }
        item {
            NeonCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text("Show my public IP", color = Color.White, fontWeight = FontWeight.Bold)
                        Text("Sends one HTTPS request to api.ipify.org to read your IP. Off = no request is made.", color = Cy.Dim, fontSize = 12.sp)
                    }
                    Switch(checked = consentIp, onCheckedChange = { consentIp = it; Core.consent.ipLookup = it })
                }
            }
        }
        item {
            NeonCard(Modifier.clickable { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); hasUsage = Core.threat.hasUsageAccess() }, accent = if (hasUsage) Cy.Green else Cy.Amber) {
                Text(if (hasUsage) "Usage access: granted" else "Usage access: tap to grant", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Lets Android tell us how many bytes each app uploaded, so we can flag unusual spikes. It doesn't reveal what was sent or where.", color = Cy.Dim, fontSize = 12.sp)
            }
        }
        item {
            NeonCard(Modifier.clickable { ctx.startActivity(Intent(Settings.ACTION_VPN_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, accent = Cy.Blue) {
                Text("Kill switch: open VPN settings", color = Color.White, fontWeight = FontWeight.Bold)
                Text("Turn on 'Always-on VPN' and 'Block connections without VPN' for CyberShield AI. Only Android can enforce this reliably.", color = Cy.Dim, fontSize = 12.sp)
            }
        }
        item {
            NeonCard(accent = Cy.Amber) {
                Text("What this app can and can't do", color = Cy.Amber, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "• It encrypts your traffic to your WireGuard server and hides your IP from websites.\n" +
                        "• It checks Wi-Fi security, VPN drops, per-app upload spikes and risky app permissions.\n" +
                        "• Android 10+ doesn't let normal apps see other apps' remote IPs/ports or drop their packets, so alerts show those fields only when available and say plainly when traffic was not blocked.\n" +
                        "• It never identifies or contacts an attacker, and never sends your data anywhere.",
                    color = Cy.Dim, fontSize = 12.sp,
                )
            }
        }
        item { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Label("Alert history (${alerts.size})"); Text("clear", color = Cy.Red, fontSize = 11.sp, modifier = Modifier.clickable { Core.alerts.clear() }) } }
        if (alerts.isEmpty()) item { Text("Nothing flagged.", color = Cy.Dim, fontSize = 12.sp) }
        items(alerts, key = { it.id }) { AlertCard(it) }
    }
}
