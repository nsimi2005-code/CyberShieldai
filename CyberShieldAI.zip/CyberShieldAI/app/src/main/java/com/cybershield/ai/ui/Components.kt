package com.cybershield.ai.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.animation.core.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybershield.ai.net.Sample
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

object Cy {
    val Bg = Color(0xFF05070A)
    val Card = Color(0xFF0B1118)
    val Line = Color(0xFF16222E)
    val Green = Color(0xFF00FF9C)
    val Blue = Color(0xFF00B8FF)
    val Red = Color(0xFFFF3B5C)
    val Amber = Color(0xFFFFB020)
    val Dim = Color(0xFF7C8B9A)
    val Mono = FontFamily.Monospace
}

@Composable
fun CyberTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(background = Cy.Bg, surface = Cy.Card, primary = Cy.Green, secondary = Cy.Blue, onBackground = Color.White, onSurface = Color.White),
        content = content,
    )
}

@Composable
fun NeonCard(modifier: Modifier = Modifier, accent: Color = Cy.Blue, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .background(Cy.Card, RoundedCornerShape(16.dp))
            .border(1.dp, Brush.linearGradient(listOf(accent.copy(alpha = .55f), Cy.Line)), RoundedCornerShape(16.dp))
            .padding(14.dp),
        content = content,
    )
}

@Composable
fun Label(t: String) = Text(t.uppercase(), color = Cy.Dim, fontSize = 10.sp, letterSpacing = 1.5.sp, fontFamily = Cy.Mono)

@Composable
fun Stat(label: String, value: String, color: Color = Color.White, modifier: Modifier = Modifier) {
    NeonCard(modifier, accent = color) {
        Label(label)
        Spacer(Modifier.height(4.dp))
        Text(value, color = color, fontSize = 17.sp, fontWeight = FontWeight.Bold, fontFamily = Cy.Mono, maxLines = 2)
    }
}

/**
 * Radar-style monitor. The sweep always turns while monitoring is on and spins faster while a
 * real scan pass is running; the centre text states the real status. It never draws "found" blips.
 */
@Composable
fun ScannerView(active: Boolean, scanning: Boolean, centerTop: String, centerBottom: String, color: Color, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "scan")
    val dur = if (scanning) 1400 else 4200
    val angle by t.animateFloat(0f, 360f, infiniteRepeatable(tween(dur, easing = LinearEasing)), label = "a")
    val pulse by t.animateFloat(0.4f, 1f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "p")
    Box(modifier.aspectRatio(1f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center; val r = size.minDimension / 2 - 6f
            for (i in 1..4) drawCircle(color.copy(alpha = .10f + .03f * i), r * i / 4, c, style = Stroke(1.5f))
            drawLine(color.copy(alpha = .12f), Offset(c.x - r, c.y), Offset(c.x + r, c.y))
            drawLine(color.copy(alpha = .12f), Offset(c.x, c.y - r), Offset(c.x, c.y + r))
            drawCircle(color.copy(alpha = .06f * pulse), r * .98f, c)
            if (active) {
                val rad = Math.toRadians(angle.toDouble())
                val end = Offset(c.x + r * cos(rad).toFloat(), c.y + r * sin(rad).toFloat())
                // trailing sweep
                for (i in 0 until 28) {
                    val a2 = Math.toRadians((angle - i * 2.2).toDouble())
                    drawLine(color.copy(alpha = (.5f - i * .018f).coerceAtLeast(0f)), c, Offset(c.x + r * cos(a2).toFloat(), c.y + r * sin(a2).toFloat()), 3f)
                }
                drawLine(color, c, end, 3f)
            }
            drawCircle(color, r, c, style = Stroke(2.5f))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(centerTop, color = color, fontSize = 20.sp, fontWeight = FontWeight.Black, fontFamily = Cy.Mono)
            Text(centerBottom, color = Cy.Dim, fontSize = 11.sp, fontFamily = Cy.Mono)
        }
    }
}

/** Rolling 60 s throughput graph (device-wide). */
@Composable
fun TrafficGraph(samples: List<Sample>, modifier: Modifier = Modifier) {
    Canvas(modifier.fillMaxWidth().height(110.dp)) {
        val peak = max(1L, samples.maxOfOrNull { max(it.rxBps, it.txBps) } ?: 1L).toFloat()
        for (i in 1..3) drawLine(Cy.Line, Offset(0f, size.height * i / 4), Offset(size.width, size.height * i / 4))
        fun line(sel: (Sample) -> Long, col: Color) {
            if (samples.size < 2) return
            val p = Path()
            samples.forEachIndexed { i, s ->
                val x = size.width * i / 59f
                val y = size.height - size.height * (sel(s) / peak) * .92f - 2f
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            drawPath(p, col.copy(alpha = .25f), style = Stroke(7f))
            drawPath(p, col, style = Stroke(2.5f))
        }
        line({ it.rxBps }, Cy.Green)
        line({ it.txBps }, Cy.Blue)
    }
}

fun fmtBytes(b: Long): String = when {
    b >= 1_000_000_000 -> "%.2f GB".format(b / 1e9)
    b >= 1_000_000 -> "%.1f MB".format(b / 1e6)
    b >= 1_000 -> "%.0f KB".format(b / 1e3)
    else -> "$b B"
}
fun fmtRate(b: Long): String = fmtBytes(b) + "/s"
