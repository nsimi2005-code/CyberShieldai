package com.novastore.app.ui
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.novastore.app.data.*
import kotlinx.coroutines.launch

@Composable private fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) =
  Column(modifier.clip(RoundedCornerShape(22.dp)).background(MaterialTheme.colorScheme.surface.copy(alpha = .6f))
    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .25f), RoundedCornerShape(22.dp)).padding(14.dp), content = content)

@Composable fun AgeBadge(r: String) = Text(r, Modifier.clip(RoundedCornerShape(6.dp)).background(NovaGradient).padding(horizontal = 8.dp, vertical = 2.dp), fontWeight = FontWeight.Bold)

@Composable fun HomeScreen(onOpen: (String) -> Unit, onAccount: () -> Unit) {
  var query by remember { mutableStateOf("") }; var cat by remember { mutableStateOf<String?>(null) }
  var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }; var err by remember { mutableStateOf<String?>(null) }
  LaunchedEffect(query, cat) { runCatching { Api.apps(cat, query) }.onSuccess { apps = it; err = null }.onFailure { err = it.message } }
  LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item { Row(verticalAlignment = Alignment.CenterVertically) {
      Text("NOVA STORE", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
      TextButton(onClick = onAccount) { Text(if (Api.session == null) "Sign in" else "Account") } } }
    item { OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search apps & games") }, shape = RoundedCornerShape(28.dp), singleLine = true) }
    item { LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      item { FilterChip(cat == null, { cat = null }, { Text("All") }) }
      items(CATEGORIES) { c -> FilterChip(cat == c, { cat = if (cat == c) null else c }, { Text(c) }) } } }
    err?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
    if (err == null && apps.isEmpty()) item { Text("No published apps yet.") }
    items(apps, key = { it.id }) { a -> Glass(Modifier.fillMaxWidth().clickable { onOpen(a.id) }) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(a.icon_url, a.name, Modifier.size(60.dp).clip(RoundedCornerShape(16.dp)).background(NovaGradient))
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
          Text(a.name, fontWeight = FontWeight.Bold); Text(a.developer_name, style = MaterialTheme.typography.bodySmall)
          Text("★ %.1f · %,d downloads".format(a.rating, a.downloads), style = MaterialTheme.typography.bodySmall) }
        AgeBadge(a.age_rating) } } }
  }
}

@Composable fun DetailScreen(id: String, onBack: () -> Unit) {
  val ctx = LocalContext.current; val scope = rememberCoroutineScope()
  var app by remember { mutableStateOf<AppItem?>(null) }; var reviews by remember { mutableStateOf<List<Review>>(emptyList()) }
  var msg by remember { mutableStateOf<String?>(null) }; var text by remember { mutableStateOf("") }; var stars by remember { mutableIntStateOf(5) }
  suspend fun load() { runCatching { app = Api.app(id); reviews = Api.reviews(id) }.onFailure { msg = it.message } }
  LaunchedEffect(id) { load() }
  val a = app ?: return Box(Modifier.fillMaxSize(), Alignment.Center) { Text(msg ?: "Loading…") }
  LazyColumn(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item { TextButton(onClick = onBack) { Text("← Back") } }
    item { Row(verticalAlignment = Alignment.CenterVertically) {
      AsyncImage(a.icon_url, a.name, Modifier.size(88.dp).clip(RoundedCornerShape(24.dp)).background(NovaGradient))
      Column(Modifier.padding(start = 14.dp)) { Text(a.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("${a.developer_name} · v${a.version}"); Row { AgeBadge(a.age_rating); Text("  %,d downloads".format(a.downloads)) } } } }
    item { Text(if (a.security_scan_status == "clean") "Security scan: passed" else "Not security-scanned yet", color = if (a.security_scan_status == "clean") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
    item { Button(onClick = { scope.launch { runCatching { Api.downloadUrl(a.id) }.onSuccess { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) }.onFailure { msg = it.message } } }, Modifier.fillMaxWidth().height(52.dp)) { Text("Download") } }
    if (a.screenshots.isNotEmpty()) item { LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) { items(a.screenshots) { AsyncImage(it, null, Modifier.height(220.dp).width(124.dp).clip(RoundedCornerShape(16.dp))) } } }
    item { Glass { Text("About", fontWeight = FontWeight.Bold); Text(a.description) } }
    item { Text("Reviews  ★ %.1f".format(a.rating), fontWeight = FontWeight.Bold) }
    if (Api.session != null) item { Glass {
      Row { (1..5).forEach { s -> Text(if (s <= stars) "★" else "☆", Modifier.clickable { stars = s }.padding(4.dp), style = MaterialTheme.typography.titleLarge) } }
      OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), placeholder = { Text("Write a review") })
      Button(onClick = { scope.launch { runCatching { Api.addReview(a.id, stars, text) }.onSuccess { text = ""; load() }.onFailure { msg = it.message } } }, enabled = text.isNotBlank()) { Text("Post") } } }
    else item { Text("Sign in to write a review.") }
    msg?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
    items(reviews, key = { it.id }) { r -> Glass(Modifier.fillMaxWidth()) { Text("★".repeat(r.rating) + "  " + r.author_name, fontWeight = FontWeight.Bold); Text(r.body) } }
  }
}

@Composable fun AuthScreen(onDone: () -> Unit) {
  val scope = rememberCoroutineScope(); var email by remember { mutableStateOf("") }; var pw by remember { mutableStateOf("") }
  var msg by remember { mutableStateOf<String?>(null) }
  Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)) {
    if (Api.session != null) { Text("Signed in as ${Api.session?.user?.email}"); Button(onClick = { Api.signOut(); onDone() }) { Text("Sign out") }; return@Column }
    Text("Welcome to NOVA", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
    OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth(), label = { Text("Email") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
    OutlinedTextField(pw, { pw = it }, Modifier.fillMaxWidth(), label = { Text("Password") }, visualTransformation = PasswordVisualTransformation())
    Button(onClick = { scope.launch { runCatching { Api.signIn(email, pw) }.onSuccess { if (Api.session != null) onDone() else msg = "Sign-in failed" }.onFailure { msg = it.message } } }, Modifier.fillMaxWidth()) { Text("Sign in") }
    OutlinedButton(onClick = { scope.launch { runCatching { Api.signUp(email, pw) }.onSuccess { msg = "Check your email to confirm your account." }.onFailure { msg = it.message } } }, Modifier.fillMaxWidth()) { Text("Create account") }
    msg?.let { Text(it) }
  }
}
