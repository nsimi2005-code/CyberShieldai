package com.novastore.app.data
import kotlinx.serialization.Serializable
@Serializable data class AppItem(
  val id: String, val name: String, val developer_name: String = "", val category: String,
  val short_description: String = "", val description: String = "", val icon_url: String? = null,
  val screenshots: List<String> = emptyList(), val age_rating: String = "3+",
  val version: String = "", val downloads: Long = 0, val rating: Double = 0.0,
  val security_scan_status: String = "not_scanned")
@Serializable data class Review(val id: String, val app_id: String, val rating: Int, val body: String, val author_name: String = "", val created_at: String = "")
@Serializable data class Session(val access_token: String, val user: SessionUser)
@Serializable data class SessionUser(val id: String, val email: String? = null)
val CATEGORIES = listOf("Games", "Education", "Tools", "Entertainment", "Productivity")
