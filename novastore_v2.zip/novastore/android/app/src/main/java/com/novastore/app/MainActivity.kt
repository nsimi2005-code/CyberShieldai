package com.novastore.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.compose.*
import com.novastore.app.ui.*
class MainActivity : ComponentActivity() {
  override fun onCreate(s: Bundle?) { super.onCreate(s); setContent { NovaTheme {
    val nav = rememberNavController()
    NavHost(nav, "home") {
      composable("home") { HomeScreen({ nav.navigate("app/$it") }, { nav.navigate("auth") }) }
      composable("app/{id}") { DetailScreen(it.arguments!!.getString("id")!!) { nav.popBackStack() } }
      composable("auth") { AuthScreen { nav.popBackStack() } }
    } } } }
}
