package com.novastore.app.data
import com.novastore.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.URLEncoder

/** Talks to the backend REST API (see backend/schema.sql). Only approved apps are readable publicly (enforced server-side by RLS). */
object Api {
  private val http = OkHttpClient()
  private val json = Json { ignoreUnknownKeys = true }
  private val base = BuildConfig.BACKEND_URL
  private val key = BuildConfig.BACKEND_KEY
  var session: Session? = null
  private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
  private fun req(path: String) = Request.Builder().url("$base$path").header("apikey", key)
    .header("Authorization", "Bearer ${session?.access_token ?: key}")
  private suspend fun call(r: Request): String = withContext(Dispatchers.IO) {
    if (base.isBlank()) error("Backend not configured. Set NOVA_BACKEND_URL in gradle.properties.")
    http.newCall(r).execute().use { if (!it.isSuccessful) error("Error ${it.code}: ${it.body?.string()}"); it.body!!.string() }
  }
  private val JSONT = "application/json".toMediaType()

  suspend fun apps(category: String? = null, query: String? = null): List<AppItem> {
    var q = "/rest/v1/public_apps?select=*&order=downloads.desc"
    if (category != null) q += "&category=eq.${enc(category)}"
    if (!query.isNullOrBlank()) q += "&name=ilike.*${enc(query)}*"
    return json.decodeFromString(call(req(q).get().build()))
  }
  suspend fun app(id: String): AppItem = json.decodeFromString<List<AppItem>>(call(req("/rest/v1/public_apps?id=eq.$id").get().build())).first()
  suspend fun reviews(id: String): List<Review> = json.decodeFromString(call(req("/rest/v1/reviews?app_id=eq.$id&order=created_at.desc").get().build()))
  suspend fun addReview(appId: String, rating: Int, body: String) {
    val b = buildJsonObject { put("app_id", appId); put("rating", rating); put("body", body) }.toString()
    call(req("/rest/v1/reviews").post(b.toRequestBody(JSONT)).build())
  }
  /** Returns a short-lived signed URL; server counts the download. */
  suspend fun downloadUrl(appId: String): String {
    val b = buildJsonObject { put("p_app_id", appId) }.toString()
    return json.decodeFromString<String>(call(req("/rest/v1/rpc/register_download").post(b.toRequestBody(JSONT)).build()))
  }
  suspend fun signIn(email: String, pw: String) { session = auth("/auth/v1/token?grant_type=password", email, pw) }
  suspend fun signUp(email: String, pw: String) { auth("/auth/v1/signup", email, pw) }
  private suspend fun auth(p: String, email: String, pw: String): Session? {
    val b = buildJsonObject { put("email", email); put("password", pw) }.toString()
    val r = call(req(p).post(b.toRequestBody(JSONT)).build())
    return runCatching { json.decodeFromString<Session>(r) }.getOrNull()
  }
  fun signOut() { session = null }
}
