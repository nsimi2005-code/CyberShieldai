package com.novastore.app.ui
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.*
val NovaCyan = Color(0xFF3EE6E0); val NovaMagenta = Color(0xFFFF4FA3); val NovaDeep = Color(0xFF070B1A)
val NovaGradient = Brush.linearGradient(listOf(NovaCyan, Color(0xFF4F7CFF), NovaMagenta))
@Composable fun NovaTheme(content: @Composable () -> Unit) {
  val dark = isSystemInDarkTheme()
  MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = NovaCyan, secondary = NovaMagenta, background = NovaDeep, surface = Color(0xFF111833))
    else lightColorScheme(primary = Color(0xFF0B7C8C), secondary = NovaMagenta, background = Color(0xFFF3F6FF)), content = content)
}
