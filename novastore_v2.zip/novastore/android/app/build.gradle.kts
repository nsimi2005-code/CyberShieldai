plugins {
  id("com.android.application"); id("org.jetbrains.kotlin.android")
  id("org.jetbrains.kotlin.plugin.compose"); id("org.jetbrains.kotlin.plugin.serialization")
}
android {
  namespace = "com.novastore.app"; compileSdk = 34
  defaultConfig {
    applicationId = "com.novastore.app"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "0.1.0"
    buildConfigField("String", "BACKEND_URL", "\"${project.findProperty("NOVA_BACKEND_URL") ?: ""}\"")
    buildConfigField("String", "BACKEND_KEY", "\"${project.findProperty("NOVA_BACKEND_KEY") ?: ""}\"")
  }
  buildFeatures { compose = true; buildConfig = true }
  compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
  kotlinOptions { jvmTarget = "17" }
}
dependencies {
  implementation(platform("androidx.compose:compose-bom:2024.09.00"))
  implementation("androidx.compose.material3:material3")
  implementation("androidx.compose.ui:ui")
  implementation("androidx.activity:activity-compose:1.9.2")
  implementation("androidx.navigation:navigation-compose:2.8.0")
  implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.5")
  implementation("com.squareup.okhttp3:okhttp:4.12.0")
  implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.7.2")
  implementation("io.coil-kt:coil-compose:2.7.0")
}
