-- NOVA STORE database (PostgreSQL / Supabase). Run in the SQL editor.
create type age_rating as enum ('3+','7+','12+','16+','18+');
create type app_status as enum ('draft','pending_review','approved','rejected','suspended');
create table public.apps (
  id uuid primary key default gen_random_uuid(),
  developer_id uuid not null references auth.users(id) on delete cascade,
  developer_name text not null, name text not null check (length(name) between 2 and 60),
  category text not null check (category in ('Games','Education','Tools','Entertainment','Productivity')),
  short_description text not null default '', description text not null default '',
  icon_url text, screenshots text[] not null default '{}', age_rating age_rating not null default '3+',
  version text not null default '1.0.0', apk_path text, downloads bigint not null default 0,
  status app_status not null default 'draft',
  security_scan_status text not null default 'not_scanned', -- never set to 'clean' without a real scanner
  created_at timestamptz not null default now());
create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  app_id uuid not null references public.apps(id) on delete cascade,
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  author_name text not null default 'User', rating int not null check (rating between 1 and 5),
  body text not null check (length(body) between 1 and 2000), created_at timestamptz not null default now(),
  unique (app_id, user_id));
grant select on public.apps to anon, authenticated; grant insert, update on public.apps to authenticated;
grant select on public.reviews to anon, authenticated; grant insert, delete on public.reviews to authenticated;
alter table public.apps enable row level security; alter table public.reviews enable row level security;
create policy "public reads approved" on public.apps for select using (status = 'approved' or developer_id = auth.uid());
create policy "dev inserts own draft" on public.apps for insert to authenticated with check (developer_id = auth.uid() and status in ('draft','pending_review') and security_scan_status = 'not_scanned');
create policy "read reviews" on public.reviews for select using (true);
create policy "write own review" on public.reviews for insert to authenticated with check (user_id = auth.uid());
create policy "delete own review" on public.reviews for delete to authenticated using (user_id = auth.uid());
create view public.public_apps with (security_invoker = on) as
  select a.id,a.name,a.developer_name,a.category,a.short_description,a.description,a.icon_url,a.screenshots,
    a.age_rating::text,a.version,a.downloads,a.security_scan_status,
    coalesce((select round(avg(rating)::numeric,1) from public.reviews r where r.app_id=a.id),0)::float as rating
  from public.apps a where a.status='approved';
grant select on public.public_apps to anon, authenticated;
-- Private bucket 'apks' must exist (Storage > New bucket, private).
create or replace function public.register_download(p_app_id uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v_path text; begin
  select apk_path into v_path from apps where id = p_app_id and status = 'approved';
  if v_path is null then raise exception 'App not available'; end if;
  update apps set downloads = downloads + 1 where id = p_app_id;
  return v_path; -- client exchanges path for a signed URL; see README
end $$;
grant execute on function public.register_download(uuid) to anon, authenticated;
