# NOVA STORE — Phase 1 (Marketplace + Accounts)

Native Android app (Kotlin, Jetpack Compose) + PostgreSQL/Supabase backend.

## Status — read first
- The included NovaStore-debug.apk was built from this source. It is a debug build and has no backend address set, so it will show "Backend not configured" until you rebuild with your own backend (below).
- No APK is included: you build it yourself (below).
- Malware scanning is NOT implemented. Every app shows "Not security-scanned yet" until a real scanner (e.g. VirusTotal) is added.
- Not yet built: Developer Center uploads, AI moderation, admin dashboard, appeals, parental controls. Planned for later phases.
- `register_download` returns the storage path; for production, replace it with a server endpoint that returns a signed URL for the private `apks` bucket.

## Backend setup
1. Create a free project at supabase.com.
2. SQL Editor → run `backend/schema.sql`.
3. Storage → create a private bucket named `apks`.
4. Copy the project URL and anon key.

## Android build
1. Open `android/` in Android Studio (Koala or newer). Let it create the Gradle wrapper and sync.
2. Add to `android/gradle.properties`:
   NOVA_BACKEND_URL=https://YOURPROJECT.supabase.co
   NOVA_BACKEND_KEY=your-anon-key
3. Build → Build APK(s). The APK is in `app/build/outputs/apk/debug/`.

## Features in this phase
Browse, search, filter by 5 categories, app pages (screenshots, description, version, age rating, downloads, scan status), ratings and reviews, sign up / sign in, download counting. Dark and light themes follow the system setting.
